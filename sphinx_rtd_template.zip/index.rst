.. sphinx-kickstart documentation master file, created by
   sphinx-quickstart on Wed Jul  8 12:01:11 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to sphinx-kickstart's documentation!
============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Sphinx-Kickstart <pages/sphinx-kickstart.rst>



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
